// frontend/src/pages/Dashboard.jsx placeholder
